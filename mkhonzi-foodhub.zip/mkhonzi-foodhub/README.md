# Mkhonzi Food Hub Website

## Run locally
npm install
npm run dev

## Build
npm run build
