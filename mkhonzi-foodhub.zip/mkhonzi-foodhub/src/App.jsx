export default function App() {
  const menuItems = [
    {
      name: "Burger Meal",
      price: "R75",
      description: "Juicy beef burger served with crispy fries and a cold drink.",
      image:
        "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=1200&auto=format&fit=crop",
    },
    {
      name: "Chicken Kota",
      price: "R65",
      description: "Loaded kota with chicken, chips, cheese, and fresh sauce.",
      image:
        "https://images.unsplash.com/photo-1550547660-d9450f859349?q=80&w=1200&auto=format&fit=crop",
    },
    {
      name: "Pizza Special",
      price: "R120",
      description: "Freshly baked pizza topped with cheese and your favorite toppings.",
      image:
        "https://images.unsplash.com/photo-1513104890138-7c749659a591?q=80&w=1200&auto=format&fit=crop",
    },
  ];

  return (
    <div className="min-h-screen bg-orange-50 text-gray-900">
      <section
        className="relative h-[90vh] bg-cover bg-center flex items-center justify-center"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1504674900247-0877df9cc836?q=80&w=1600&auto=format&fit=crop')",
        }}
      >
        <div className="absolute inset-0 bg-black/60"></div>

        <div className="relative z-10 text-center text-white px-6 max-w-3xl">
          <h1 className="text-5xl md:text-7xl font-extrabold mb-6 tracking-tight">
            Mkhonzi Food Hub
          </h1>

          <p className="text-lg md:text-2xl mb-8 text-gray-200">
            Delicious meals delivered fresh to your doorstep.
          </p>

          <a
            href="#menu"
            className="bg-orange-500 hover:bg-orange-600 transition px-8 py-4 rounded-2xl text-lg font-semibold shadow-lg"
          >
            Order Now
          </a>
        </div>
      </section>

      <section id="menu" className="py-20 bg-white px-6 md:px-20">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-14">
            <h2 className="text-5xl font-bold mb-4">Our Menu</h2>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-10">
            {menuItems.map((item, index) => (
              <div
                key={index}
                className="bg-orange-50 rounded-3xl overflow-hidden shadow-xl"
              >
                <img
                  src={item.image}
                  alt={item.name}
                  className="h-60 w-full object-cover"
                />

                <div className="p-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-2xl font-bold">{item.name}</h3>
                    <span className="bg-orange-500 text-white px-4 py-1 rounded-full font-semibold">
                      {item.price}
                    </span>
                  </div>

                  <p className="text-gray-600 mb-6">{item.description}</p>

                  <button className="w-full bg-black text-white py-3 rounded-2xl">
                    Pay Online
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <footer className="bg-black text-white text-center py-6">
        © 2026 Mkhonzi Food Hub
      </footer>
    </div>
  );
}
